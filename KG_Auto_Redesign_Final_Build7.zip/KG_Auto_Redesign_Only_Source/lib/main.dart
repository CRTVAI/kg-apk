import 'dart:async';

import 'package:cargo/controllers/container_controller.dart';
import 'package:cargo/controllers/home_controller.dart';
import 'package:cargo/controllers/operator_controller.dart';
import 'package:cargo/controllers/transaction_controller.dart';
import 'package:cargo/controllers/user_controller.dart';
import 'package:cargo/controllers/vehicle_controller.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:permission_handler/permission_handler.dart';

import 'controllers/auth_controller.dart';
import 'firebase_options.dart';
import 'localizations/languages.dart';
import 'ui/splash/splash_screen.dart';
import 'ui/styles/app_theme.dart';
import 'utils/push_notification_service.dart';

Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  /// On click listner
  // navigateToDetailsPage(message);
}
navigateToDetailsPage(RemoteMessage message) {
  PushNotificationService().navigateToDetailsPage(message);
}

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: AppTheme.canvas,
      statusBarIconBrightness: Brightness.dark,
      statusBarBrightness: Brightness.light,
      systemNavigationBarColor: AppTheme.surface,
      systemNavigationBarIconBrightness: Brightness.dark,
    ),
  );

  runApp(const MyApp());
  WidgetsBinding.instance.addPostFrameCallback((_) {
    unawaited(_initializeAppServices());
  });
}

Future<void> _initializeAppServices() async {
  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
    FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
    await PushNotificationService().setupInteractedMessage();

    if (await Permission.notification.isDenied) {
      unawaited(Permission.notification.request());
    }

    final initialMessage = await FirebaseMessaging.instance.getInitialMessage();
    if (initialMessage != null) {
      Timer(const Duration(seconds: 3), () {
        navigateToDetailsPage(initialMessage);
      });
    }
  } catch (err, stackTrace) {
    debugPrint('Startup service initialization failed: $err');
    debugPrintStack(stackTrace: stackTrace);
  }
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    Get.put(AuthController());
    Get.put(HomeController());
    Get.put(UserController());
    Get.put(VehicleController());
    Get.put(ContainerController());
    Get.put(TransactionController());
    Get.put(OperatorController());

    return ScreenUtilInit(
      designSize: const Size(360, 800),
      minTextAdapt: true,
      builder: (context, child) {
        return GetMaterialApp(
          locale: const Locale('en', 'US'),
          translations: Languages(),
          fallbackLocale: const Locale('en', 'US'),
          debugShowCheckedModeBanner: false,
          title: "appname".tr,
          theme: AppTheme.light(),
          home: child,
        );
      },
      child: const SplashScreen(),
    );
  }
}
